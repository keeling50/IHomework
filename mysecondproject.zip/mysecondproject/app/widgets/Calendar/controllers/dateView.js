/*
 * (c) Copyright 2014 ishan.singh. All Rights Reserved.
 */

var args = arguments[0] || {};

$.dateLabel.text = args.date;
$.dateLabel.color = args.textColor;
$.dateView.backgroundColor = args.backgroundColor;
