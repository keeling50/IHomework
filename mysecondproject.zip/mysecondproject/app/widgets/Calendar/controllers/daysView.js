/*
* (c) Copyright 2014 ishan.singh. All Rights Reserved.
*/

//arguments
var args = arguments[0] || {};

$.dayname.text = args.dayName;
