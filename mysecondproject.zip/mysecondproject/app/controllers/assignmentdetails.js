var args = arguments[0] || {};
$.titleLabel.text = args.title || 'Default Title';
$.authorLabel.text = args.author || 'Default author'; 
