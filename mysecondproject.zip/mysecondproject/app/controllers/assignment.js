$.assWindow.open();
