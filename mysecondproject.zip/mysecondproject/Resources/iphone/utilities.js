function getCurrentLocation() {
    var deferred = Q.defer();
    if (Ti.Geolocation.getLocationServicesEnabled()) {
        Ti.Geolocation.accuracy = Ti.Geolocation.ACCURACY_HIGH;
        Ti.Geolocation.distanceFilter = 10;
        Ti.Geolocation.addEventListener("location", function listener(_location) {
            locationCallbackHandler(_location, deferred);
            Ti.Geolocation.removeEventListener("location", listener);
        });
    } else {
        alert("Location Services are not enabled");
        deferred.reject({
            location: null,
            message: "Location Services are not enabled"
        });
    }
    return deferred.promise;
}

function locationCallbackHandler(_location, _deferred) {
    if (!_location.error && _location && _location.coords) _deferred.resolve({
        location: _location.coords,
        message: null
    }); else {
        alert("Location Services Error: " + _location.error);
        _deferred.reject({
            location: null,
            message: _location.error
        });
    }
}

function reverseGeocoder(_lat, _lng) {
    var title;
    var deferred = Q.defer();
    Ti.Geolocation.reverseGeocoder(_lat, _lng, function(_data) {
        if (_data.success) {
            Ti.API.debug("reverseGeo " + JSON.stringify(_data, null, 2));
            var place = _data.places[0];
            title = "" === place.city ? place.address : place.street + " " + place.city;
            deferred.resolve({
                title: title,
                place: place,
                location: {
                    latitude: _lat,
                    longitude: _lng
                }
            });
        } else {
            title = "No Address Found: " + _lat + ", " + _lng;
            deferred.reject({
                title: title,
                location: {
                    latitude: _lat,
                    longitude: _lng
                }
            });
        }
    });
    return deferred.promise;
}

var Q = require("q");

exports.reverseGeocoder = reverseGeocoder;

exports.getCurrentLocation = getCurrentLocation;