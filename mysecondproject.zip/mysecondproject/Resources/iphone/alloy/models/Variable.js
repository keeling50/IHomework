var Alloy = require("alloy"), _ = require("alloy/underscore")._, model, collection;

exports.definition = {
    config: {
        columns: {
            name: "TEXT",
            nickname: "TEXT",
            fighterId: "TEXT PRIMARY KEY"
        },
        adapter: {
            type: "sql",
            collection_name: "variable",
            idAttribute: "fighterId"
        }
    }
};

model = Alloy.M("variable", exports.definition, []);

collection = Alloy.C("variable", exports.definition, model);

exports.Model = model;

exports.Collection = collection;