function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function closeWindow() {
        $.win3.close();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "menu";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.win3 = Ti.UI.createWindow({
        id: "win3",
        title: "Menu",
        backgroundColor: "white"
    });
    $.__views.win3 && $.addTopLevelView($.__views.win3);
    $.__views.calbutton = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "60%",
        color: "black",
        title: "Calendar",
        id: "calbutton",
        top: "10"
    });
    $.__views.win3.add($.__views.calbutton);
    $.__views.__alloyId17 = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "60%",
        color: "black",
        title: "Classes",
        top: "50",
        id: "__alloyId17"
    });
    $.__views.win3.add($.__views.__alloyId17);
    closeWindow ? $.__views.__alloyId17.addEventListener("click", closeWindow) : __defers["$.__views.__alloyId17!click!closeWindow"] = true;
    $.__views.notebutton = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "60%",
        color: "black",
        title: "Notes",
        id: "notebutton",
        top: "90"
    });
    $.__views.win3.add($.__views.notebutton);
    $.__views.assbutton = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "60%",
        color: "black",
        title: "Assignment",
        id: "assbutton",
        top: "130"
    });
    $.__views.win3.add($.__views.assbutton);
    $.__views.__alloyId18 = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "60%",
        color: "black",
        title: "Close Menu",
        bottom: "10",
        id: "__alloyId18"
    });
    $.__views.win3.add($.__views.__alloyId18);
    closeWindow ? $.__views.__alloyId18.addEventListener("click", closeWindow) : __defers["$.__views.__alloyId18!click!closeWindow"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.calbutton.addEventListener("click", function() {
        calendar = Alloy.createController("calendar");
    });
    $.assbutton.addEventListener("click", function() {
        assignment = Alloy.createController("assignment");
    });
    $.notebutton.addEventListener("click", function() {
        notes = Alloy.createController("notes");
    });
    __defers["$.__views.__alloyId17!click!closeWindow"] && $.__views.__alloyId17.addEventListener("click", closeWindow);
    __defers["$.__views.__alloyId18!click!closeWindow"] && $.__views.__alloyId18.addEventListener("click", closeWindow);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;