function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function handleLoginClick(_event) {
        Ti.API.debug("clicked: " + _event.source.id);
        var aUser = Alloy.createModel("User");
        aUser.login($.login_email.value, $.login_password.value).then(function(_model) {
            Alloy.Globals.loggedIn = true;
            Alloy.Globals.CURRENT_USER = _model;
            callback && callback(_model);
        }, function(_error) {
            var errorMsg = JSON.stringify(_error);
            alert(_error.message);
            Ti.API.error("Error: " + errorMsg);
        });
    }
    function handleShowAcctClick(_event) {
        Ti.API.debug("clicked: " + _event.source.id);
        var animation = require("alloy/animation");
        var moveToTop = Ti.UI.createAnimation({
            top: "0dp",
            duration: 1
        });
        $.createAcctView.animate(moveToTop, function() {
            animation.crossFade($.loginAcctView, $.createAcctView, 500, function() {
                var moveToBottom = Ti.UI.createAnimation({
                    top: "500dp",
                    duration: 1
                });
                $.loginAcctView.animate(moveToBottom);
            });
        });
    }
    function handleCreateAccountClick() {
        if ($.acct_password.value !== $.acct_password_confirmation.value) {
            alert("Please re-enter information");
            return;
        }
        var params = {
            first_name: $.acct_fname.value,
            last_name: $.acct_lname.value,
            username: $.acct_email.value,
            email: $.acct_email.value,
            password: $.acct_password.value,
            password_confirmation: $.acct_password_confirmation.value
        };
        var user = Alloy.createModel("User");
        user.createAccount(params).then(function(_model) {
            Alloy.Globals.loggedIn = true;
            Alloy.Globals.CURRENT_USER = _model;
            callback && callback(_model);
        }, function(_error) {
            var errorMsg = JSON.stringify(_error);
            alert(_error.message);
            Ti.API.error("Error: " + errorMsg);
        });
    }
    function handleShowLoginClick(_event) {
        Ti.API.debug("clicked: " + _event.source.id);
        var animation = require("alloy/animation");
        var moveToTop = Ti.UI.createAnimation({
            top: "0dp",
            duration: 1
        });
        $.loginAcctView.animate(moveToTop, function() {
            animation.crossFade($.createAcctView, $.loginAcctView, 500, function() {
                var moveToBottom = Ti.UI.createAnimation({
                    top: "500dp",
                    duration: 1
                });
                $.createAcctView.animate(moveToBottom);
            });
        });
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "User";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.User = Ti.UI.createWindow({
        backgroundColor: "white",
        exitOnClose: true,
        id: "User"
    });
    $.__views.User && $.addTopLevelView($.__views.User);
    $.__views.__alloyId0 = Ti.UI.createScrollView({
        contentHeight: Ti.UI.SIZE,
        contentWidth: Ti.UI.SIZE,
        id: "__alloyId0"
    });
    $.__views.User.add($.__views.__alloyId0);
    $.__views.loginAcctView = Ti.UI.createView({
        opacity: 1,
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        top: "40dp",
        layout: "vertical",
        backgroundColor: "transparent",
        id: "loginAcctView"
    });
    $.__views.__alloyId0.add($.__views.loginAcctView);
    $.__views.accountText = Ti.UI.createLabel({
        width: "80%",
        height: Ti.UI.SIZE,
        color: "blue",
        textAlign: "center",
        text: "ACS Starter Application Template",
        font: {
            fontSize: "24dp",
            fontWeight: "bold"
        },
        id: "accountText"
    });
    $.__views.loginAcctView.add($.__views.accountText);
    $.__views.cavContainer = Ti.UI.createView({
        top: "20dp",
        width: "280dp",
        height: Ti.UI.SIZE,
        layout: "vertical",
        id: "cavContainer"
    });
    $.__views.loginAcctView.add($.__views.cavContainer);
    $.__views.login_email = Ti.UI.createTextField({
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_NONE,
        borderColor: "gray",
        autocapitalization: Ti.UI.TEXT_AUTOCAPITALIZATION_NONE,
        autocorrect: false,
        top: "6dp",
        left: "4dp",
        bottom: "2dp",
        right: "4dp",
        paddingLeft: "4dp",
        backgroundColor: "white",
        color: "black",
        width: "260dp",
        height: "40dp",
        border: ".5em",
        borderWidth: ".5em",
        hintText: "email address",
        id: "login_email"
    });
    $.__views.cavContainer.add($.__views.login_email);
    $.__views.login_password = Ti.UI.createTextField({
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_NONE,
        borderColor: "gray",
        autocapitalization: Ti.UI.TEXT_AUTOCAPITALIZATION_NONE,
        autocorrect: false,
        top: "6dp",
        left: "4dp",
        bottom: "2dp",
        right: "4dp",
        paddingLeft: "4dp",
        backgroundColor: "white",
        color: "black",
        width: "260dp",
        height: "40dp",
        border: ".5em",
        borderWidth: ".5em",
        passwordMask: true,
        hintText: "password",
        id: "login_password"
    });
    $.__views.cavContainer.add($.__views.login_password);
    $.__views.__alloyId1 = Ti.UI.createView({
        top: "10dp",
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        layout: "horizontal",
        id: "__alloyId1"
    });
    $.__views.cavContainer.add($.__views.__alloyId1);
    $.__views.doLoginBtn = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "120dp",
        color: "black",
        top: "6dp",
        height: "36dp",
        font: {
            fontSize: "13dp"
        },
        left: "0dp",
        id: "doLoginBtn",
        title: "Login"
    });
    $.__views.__alloyId1.add($.__views.doLoginBtn);
    handleLoginClick ? $.__views.doLoginBtn.addEventListener("click", handleLoginClick) : __defers["$.__views.doLoginBtn!click!handleLoginClick"] = true;
    $.__views.doShowCreateAccountBtn = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "120dp",
        color: "black",
        top: "6dp",
        height: "36dp",
        font: {
            fontSize: "13dp"
        },
        left: "20dp",
        id: "doShowCreateAccountBtn",
        title: "Create Account"
    });
    $.__views.__alloyId1.add($.__views.doShowCreateAccountBtn);
    handleShowAcctClick ? $.__views.doShowCreateAccountBtn.addEventListener("click", handleShowAcctClick) : __defers["$.__views.doShowCreateAccountBtn!click!handleShowAcctClick"] = true;
    $.__views.createAcctView = Ti.UI.createView({
        opacity: 0,
        top: "500dp",
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        layout: "vertical",
        backgroundColor: "transparent",
        id: "createAcctView"
    });
    $.__views.__alloyId0.add($.__views.createAcctView);
    $.__views.accountText = Ti.UI.createLabel({
        width: "80%",
        height: Ti.UI.SIZE,
        color: "blue",
        textAlign: "center",
        text: "ACS Starter Application Template",
        font: {
            fontSize: "24dp",
            fontWeight: "bold"
        },
        id: "accountText"
    });
    $.__views.createAcctView.add($.__views.accountText);
    $.__views.cavContainer = Ti.UI.createView({
        top: "20dp",
        width: "280dp",
        height: Ti.UI.SIZE,
        layout: "vertical",
        id: "cavContainer"
    });
    $.__views.createAcctView.add($.__views.cavContainer);
    $.__views.acct_fname = Ti.UI.createTextField({
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_NONE,
        borderColor: "gray",
        autocapitalization: Ti.UI.TEXT_AUTOCAPITALIZATION_NONE,
        autocorrect: false,
        top: "6dp",
        left: "4dp",
        bottom: "2dp",
        right: "4dp",
        paddingLeft: "4dp",
        backgroundColor: "white",
        color: "black",
        width: "260dp",
        height: "40dp",
        border: ".5em",
        borderWidth: ".5em",
        hintText: "first name",
        id: "acct_fname"
    });
    $.__views.cavContainer.add($.__views.acct_fname);
    $.__views.acct_lname = Ti.UI.createTextField({
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_NONE,
        borderColor: "gray",
        autocapitalization: Ti.UI.TEXT_AUTOCAPITALIZATION_NONE,
        autocorrect: false,
        top: "6dp",
        left: "4dp",
        bottom: "2dp",
        right: "4dp",
        paddingLeft: "4dp",
        backgroundColor: "white",
        color: "black",
        width: "260dp",
        height: "40dp",
        border: ".5em",
        borderWidth: ".5em",
        hintText: "last name",
        id: "acct_lname"
    });
    $.__views.cavContainer.add($.__views.acct_lname);
    $.__views.acct_email = Ti.UI.createTextField({
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_NONE,
        borderColor: "gray",
        autocapitalization: Ti.UI.TEXT_AUTOCAPITALIZATION_NONE,
        autocorrect: false,
        top: "6dp",
        left: "4dp",
        bottom: "2dp",
        right: "4dp",
        paddingLeft: "4dp",
        backgroundColor: "white",
        color: "black",
        width: "260dp",
        height: "40dp",
        border: ".5em",
        borderWidth: ".5em",
        hintText: "email address",
        id: "acct_email"
    });
    $.__views.cavContainer.add($.__views.acct_email);
    $.__views.acct_password = Ti.UI.createTextField({
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_NONE,
        borderColor: "gray",
        autocapitalization: Ti.UI.TEXT_AUTOCAPITALIZATION_NONE,
        autocorrect: false,
        top: "6dp",
        left: "4dp",
        bottom: "2dp",
        right: "4dp",
        paddingLeft: "4dp",
        backgroundColor: "white",
        color: "black",
        width: "260dp",
        height: "40dp",
        border: ".5em",
        borderWidth: ".5em",
        passwordMask: true,
        hintText: "password",
        id: "acct_password"
    });
    $.__views.cavContainer.add($.__views.acct_password);
    $.__views.acct_password_confirmation = Ti.UI.createTextField({
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_NONE,
        borderColor: "gray",
        autocapitalization: Ti.UI.TEXT_AUTOCAPITALIZATION_NONE,
        autocorrect: false,
        top: "6dp",
        left: "4dp",
        bottom: "2dp",
        right: "4dp",
        paddingLeft: "4dp",
        backgroundColor: "white",
        color: "black",
        width: "260dp",
        height: "40dp",
        border: ".5em",
        borderWidth: ".5em",
        passwordMask: true,
        hintText: "password confirmation",
        id: "acct_password_confirmation"
    });
    $.__views.cavContainer.add($.__views.acct_password_confirmation);
    $.__views.__alloyId2 = Ti.UI.createView({
        top: "10dp",
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        layout: "horizontal",
        id: "__alloyId2"
    });
    $.__views.cavContainer.add($.__views.__alloyId2);
    $.__views.doCreateAccountBtn = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "120dp",
        color: "black",
        top: "6dp",
        height: "36dp",
        font: {
            fontSize: "13dp"
        },
        left: "10dp",
        id: "doCreateAccountBtn",
        title: "Create Account"
    });
    $.__views.__alloyId2.add($.__views.doCreateAccountBtn);
    handleCreateAccountClick ? $.__views.doCreateAccountBtn.addEventListener("click", handleCreateAccountClick) : __defers["$.__views.doCreateAccountBtn!click!handleCreateAccountClick"] = true;
    $.__views.doCancelBtn = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "120dp",
        color: "black",
        top: "6dp",
        height: "36dp",
        font: {
            fontSize: "13dp"
        },
        left: "10dp",
        id: "doCancelBtn",
        title: "Cancel"
    });
    $.__views.__alloyId2.add($.__views.doCancelBtn);
    handleShowLoginClick ? $.__views.doCancelBtn.addEventListener("click", handleShowLoginClick) : __defers["$.__views.doCancelBtn!click!handleShowLoginClick"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    var args = arguments[0] || {};
    var callback = args.callback;
    __defers["$.__views.doLoginBtn!click!handleLoginClick"] && $.__views.doLoginBtn.addEventListener("click", handleLoginClick);
    __defers["$.__views.doShowCreateAccountBtn!click!handleShowAcctClick"] && $.__views.doShowCreateAccountBtn.addEventListener("click", handleShowAcctClick);
    __defers["$.__views.doCreateAccountBtn!click!handleCreateAccountClick"] && $.__views.doCreateAccountBtn.addEventListener("click", handleCreateAccountClick);
    __defers["$.__views.doCancelBtn!click!handleShowLoginClick"] && $.__views.doCancelBtn.addEventListener("click", handleShowLoginClick);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;