function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "notes";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    $.__views.notesWindow = Ti.UI.createWindow({
        id: "notesWindow",
        title: "Notes"
    });
    $.__views.__alloyId19 = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "blue",
        text: "Notes Tab",
        id: "__alloyId19"
    });
    $.__views.notesWindow.add($.__views.__alloyId19);
    $.__views.notes = Ti.UI.createTab({
        window: $.__views.notesWindow,
        title: "Notes",
        id: "notes"
    });
    $.__views.notes && $.addTopLevelView($.__views.notes);
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.notesWindow.open();
    var win = Ti.UI.createWindow({
        backgroundColor: "white"
    });
    var textArea = Ti.UI.createTextArea({
        borderWidth: 2,
        borderColor: "#bbb",
        borderRadius: 5,
        color: "#888",
        font: {
            fontSize: 20,
            fontWeight: "bold"
        },
        keyboardType: Ti.UI.KEYBOARD_APPEARANCE_DEFAULT,
        returnKeyType: Ti.UI.RETURNKEY_GO,
        textAlign: "left",
        value: "Notes",
        top: 30,
        width: 300,
        height: 470
    });
    var button = Titanium.UI.createButton({
        title: "Save",
        bottom: 10,
        width: 100,
        height: 50
    });
    button.addEventListener("click", function() {
        Titanium.API.info("Saved the Note");
    });
    win.add(textArea);
    win.add(button);
    win.open();
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;