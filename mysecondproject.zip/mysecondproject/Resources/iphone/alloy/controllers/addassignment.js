function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function addassignment() {
        var assignment = Alloy.createModel("assignment", {
            title: $.titleInput.value,
            author: $.authorInput.value
        });
        myassignment.add(assignment);
        assignment.save();
        $.addassignment.close();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "addassignment";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.addassignment = Ti.UI.createWindow({
        backgroundColor: "white",
        exitOnClose: true,
        backgroundImage: "images/global/founderslibrhoward1.jpg",
        id: "addassignment"
    });
    $.__views.addassignment && $.addTopLevelView($.__views.addassignment);
    $.__views.__alloyId3 = Ti.UI.createView({
        layout: "vertical",
        id: "__alloyId3"
    });
    $.__views.addassignment.add($.__views.__alloyId3);
    $.__views.titleInput = Ti.UI.createTextField({
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
        borderColor: "black",
        id: "titleInput",
        hintText: "Title..."
    });
    $.__views.__alloyId3.add($.__views.titleInput);
    $.__views.authorInput = Ti.UI.createTextField({
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
        borderColor: "black",
        id: "authorInput",
        hintText: "Author..."
    });
    $.__views.__alloyId3.add($.__views.authorInput);
    $.__views.insertAssignmentButton = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "60%",
        color: "black",
        title: "Add",
        id: "insertAssignmentButton"
    });
    $.__views.__alloyId3.add($.__views.insertAssignmentButton);
    addassignment ? $.__views.insertAssignmentButton.addEventListener("click", addassignment) : __defers["$.__views.insertAssignmentButton!click!addassignment"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    var myassignment = Alloy.Collections.assignment;
    __defers["$.__views.insertAssignmentButton!click!addassignment"] && $.__views.insertAssignmentButton.addEventListener("click", addassignment);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;