function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "calendar";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    $.__views.calWindow = Ti.UI.createWindow({
        id: "calWindow",
        title: "Calendar"
    });
    $.__views.__alloyId6 = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "blue",
        text: "Calendar Tab",
        id: "__alloyId6"
    });
    $.__views.calWindow.add($.__views.__alloyId6);
    $.__views.calendar = Ti.UI.createTab({
        window: $.__views.calWindow,
        title: "Calendar",
        id: "calendar"
    });
    $.__views.calendar && $.addTopLevelView($.__views.calendar);
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.calWindow.open();
    Titanium.Calendar = Ti.Calendar = require("ag.calendar");
    Ti.Calendar.dataSource("EventKit");
    var platform = Titanium.Platform.osname;
    var window = Ti.UI.createWindow({
        title: "Calendar",
        backgroundColor: "black",
        modal: true
    });
    var calendarView = Ti.Calendar.createView({
        top: 20,
        editable: true,
        color: "white"
    });
    var options = Ti.UI.createButton({
        title: "Options"
    });
    options.addEventListener("click", function() {
        var dialog = Ti.UI.createOptionDialog({
            options: [ "Set custom date", "Delete all events", "Check calendar access", "Get event list", "Cancel" ],
            title: "Calendar options",
            cancel: 4
        });
        dialog.addEventListener("click", function(e) {
            if (0 == e.index) {
                var d = new Date();
                d.setDate(d.getDate() + 3);
                calendarView.selectDate(d);
            } else if (1 == e.index) {
                Ti.API.info("Datastore: " + Ti.Calendar.ds);
                if ("coredata" != Ti.Calendar.ds) {
                    alert("This function is only available while using CoreData as your datasource.");
                    return;
                }
                Ti.API.info("Deleting all events...");
                Ti.Calendar.deleteAllEvents();
            } else if (2 == e.index) alert(true == Ti.Calendar.hasCalendarAccess ? "Yep, I have access to the calendar!" : "Nope, no access to users calendar."); else if (3 == e.index) {
                var from = new Date();
                from.setMinutes(from.getMinutes() - 10);
                var Events = Ti.Calendar.fetchEvents({
                    fromDate: from,
                    toDate: new Date()
                });
                if (Events) for (var i = 0; i < Events.length; i++) Ti.API.info("Title: " + Events[i].title); else Ti.API.info("No events found");
            }
        });
        dialog.show();
    });
    var monthNames = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
    var todayButton = Ti.UI.createButton({
        title: "Today"
    });
    todayButton.addEventListener("click", function() {
        calendarView.selectTodaysDate();
    });
    calendarView.addEventListener("date:clicked", function(e) {
        var date_clicked = new Date(e.event.date);
        Ti.API.info("Date clicked: " + monthNames[date_clicked.getMonth()] + " " + date_clicked.getDate() + ".");
    });
    calendarView.addEventListener("date:longpress", function(e) {
        var date_clicked = new Date(e.event.date);
        var dialog = Ti.UI.createAlertDialog({
            message: "Would you like to add a new event on " + monthNames[date_clicked.getMonth()] + " " + date_clicked.getDate() + ". ?",
            buttonNames: [ "Yeah!", "Cancel" ],
            cancel: 1,
            title: $.titleInput.value
        });
        var endDate = date_clicked;
        endDate.setHours(endDate.getHours() + 3);
        dialog.addEventListener("click", function(e) {
            if (0 == e.index) {
                Ti.Calendar.addEvent({
                    title: "Added event",
                    startDate: date_clicked,
                    endDate: endDate,
                    location: "At home",
                    identifier: Ti.Calendar.identifier
                });
                setTimeout(function() {
                    calendarView.selectTodaysDate();
                }, 1e3);
            }
        });
        dialog.show();
    });
    calendarView.addEventListener("month:next", function() {
        Ti.API.info("Moving to next month");
    });
    calendarView.addEventListener("month:previous", function() {
        Ti.API.info("Moving to previous month");
    });
    calendarView.addEventListener("event:clicked", function(e) {
        var event = e.event;
        Ti.API.info(JSON.stringify(event));
        var toDateObj = new Date(event.startDate);
        Ti.API.info("This event will start: " + toDateObj.toUTCString());
    });
    if ("ipad" == platform) {
        var showCalendar = Ti.UI.createButton({
            title: "Show Calendar"
        });
        var popover = Ti.UI.iPad.createPopover({
            width: 320,
            height: 500,
            title: "Calendar"
        });
        popover.add(calendarView);
        showCalendar.addEventListener("click", function() {
            popover.show({
                view: showCalendar
            });
        });
        popover.leftNavButton = options;
        popover.rightNavButton = todayButton;
        window.add(showCalendar);
    } else {
        window.setLeftNavButton(options);
        window.setRightNavButton(todayButton);
        window.add(calendarView);
    }
    window.open({
        animated: true
    });
    setTimeout(function() {
        calendarView.selectTodaysDate();
    }, 1e3);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;