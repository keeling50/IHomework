function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function __alloyId14(e) {
        if (e && e.fromAdapter) return;
        __alloyId14.opts || {};
        var models = __alloyId13.models;
        var len = models.length;
        var rows = [];
        for (var i = 0; len > i; i++) {
            var __alloyId10 = models[i];
            __alloyId10.__transform = {};
            var __alloyId12 = Ti.UI.createTableViewRow({
                title: "undefined" != typeof __alloyId10.__transform["title"] ? __alloyId10.__transform["title"] : __alloyId10.get("title"),
                author: "undefined" != typeof __alloyId10.__transform["author"] ? __alloyId10.__transform["author"] : __alloyId10.get("author")
            });
            rows.push(__alloyId12);
            showAssignment ? __alloyId12.addEventListener("click", showAssignment) : __defers["__alloyId12!click!showAssignment"] = true;
        }
        $.__views.__alloyId9.setData(rows);
    }
    function openBlueWindow() {
        var win3 = Alloy.createController("menu").getView();
        $.navGroupWin.openWindow(win3);
    }
    function showAssignment(event) {
        var selectedBook = event.source;
        var args = {
            title: selectedBook.title,
            author: selectedBook.author,
            "class": selectedBook.class
        };
        var assignmentview = Alloy.createController("assignmentdetails", args).getView();
        $.navGroupWin.openWindow(assignmentview);
    }
    function addassignment() {
        var myAddassignment = Alloy.createController("addassignment", {}).getView();
        $.navGroupWin.openWindow(myAddassignment);
    }
    function userLoggedIn(_user) {
        if (!$.alreadyOpenedIndex) {
            $.mainWindow.open();
            $.alreadyOpenedIndex = true;
        }
        Alloy.Globals.CURRENT_USER = _user;
        $.logoutBtn.title = "Logout: " + _user.get("username");
        _user.getCurrentLocation().then(function(_results) {
            Ti.API.debug("_results " + JSON.stringify(_results, null, 2));
        }, function(_error) {
            Ti.API.error("_error " + JSON.stringify(_error));
        });
    }
    function userNotLoggedIn() {
        var ctrl = Alloy.createController("User", {
            callback: function(_user) {
                userLoggedIn(_user);
                ctrl.getView().close();
                ctrl = nil;
            }
        });
        ctrl.getView().open();
    }
    function doLogout() {
        Alloy.Globals.CURRENT_USER && Alloy.Globals.CURRENT_USER.logout().then(function() {
            Alloy.Globals.CURRENT_USER = null;
            console.log("logged out!");
            userNotLoggedIn();
        }, function(_error) {
            alert(_error.message);
        });
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "index";
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    Alloy.Collections.instance("assignment");
    $.__views.mainWindow = Ti.UI.createWindow({
        backgroundColor: "white",
        exitOnClose: "true",
        backgroundImage: "images/global/founderslibrhoward1.jpg",
        id: "mainWindow",
        title: "Classes"
    });
    $.__views.__alloyId9 = Ti.UI.createTableView({
        id: "__alloyId9"
    });
    $.__views.mainWindow.add($.__views.__alloyId9);
    var __alloyId13 = Alloy.Collections["assignment"] || assignment;
    __alloyId13.on("fetch destroy change add remove reset", __alloyId14);
    $.__views.add = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "60%",
        color: "black",
        id: "add",
        title: "New "
    });
    addassignment ? $.__views.add.addEventListener("click", addassignment) : __defers["$.__views.add!click!addassignment"] = true;
    $.__views.mainWindow.rightNavButton = $.__views.add;
    $.__views.menu = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "60%",
        color: "black",
        id: "menu",
        title: "Menu "
    });
    openBlueWindow ? $.__views.menu.addEventListener("click", openBlueWindow) : __defers["$.__views.menu!click!openBlueWindow"] = true;
    $.__views.mainWindow.leftNavButton = $.__views.menu;
    $.__views.logoutBtn = Ti.UI.createButton({
        borderColor: "grey",
        borderWidth: ".5em",
        width: "60%",
        color: "black",
        title: "Logout",
        id: "logoutBtn",
        bottom: "50dp"
    });
    $.__views.mainWindow.add($.__views.logoutBtn);
    doLogout ? $.__views.logoutBtn.addEventListener("click", doLogout) : __defers["$.__views.logoutBtn!click!doLogout"] = true;
    $.__views.navGroupWin = Ti.UI.iOS.createNavigationWindow({
        window: $.__views.mainWindow,
        id: "navGroupWin"
    });
    $.__views.navGroupWin && $.addTopLevelView($.__views.navGroupWin);
    exports.destroy = function() {
        __alloyId13.off("fetch destroy change add remove reset", __alloyId14);
    };
    _.extend($, $.__views);
    var aUser = Alloy.createModel("User");
    var myassignment = Alloy.Collections.assignment;
    var assignment = Alloy.createModel("assignment", {
        title: "Mobile App Development",
        author: "Monday-Wednesday-Friday"
    });
    myassignment.add(assignment);
    assignment.save();
    aUser.authenticated() ? aUser.showMe().then(function(_user) {
        userLoggedIn(_user);
    }, function() {
        alert("Application Error\n " + _response.error.message);
        Ti.API.error(JSON.stringify(_response.error, null, 2));
        userNotLoggedIn();
    }) : userNotLoggedIn();
    $.mainWindow.addEventListener("androidback", function() {
        $.mainWindow.close();
        $.mainWindow.activity.finish();
    });
    $.navGroupWin.open();
    __defers["__alloyId12!click!showAssignment"] && __alloyId12.addEventListener("click", showAssignment);
    __defers["$.__views.add!click!addassignment"] && $.__views.add.addEventListener("click", addassignment);
    __defers["$.__views.menu!click!openBlueWindow"] && $.__views.menu.addEventListener("click", openBlueWindow);
    __defers["$.__views.logoutBtn!click!doLogout"] && $.__views.logoutBtn.addEventListener("click", doLogout);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;