function WPATH(s) {
    var index = s.lastIndexOf("/");
    var path = -1 === index ? "Calendar/" + s : s.substring(0, index) + "/Calendar/" + s.substring(index + 1);
    return path;
}

function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    new (require("alloy/widget"))("Calendar");
    this.__widgetId = "Calendar";
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "Arrow";
    if (arguments[0]) {
        __processArg(arguments[0], "__parentSymbol");
        __processArg(arguments[0], "$model");
        __processArg(arguments[0], "__itemTemplate");
    }
    var $ = this;
    var exports = {};
    $.__views.buttonView = Ti.UI.createView({
        height: 40,
        width: 40,
        backgroundColor: "transparent",
        id: "buttonView"
    });
    $.__views.buttonView && $.addTopLevelView($.__views.buttonView);
    $.__views.arrowImage = Ti.UI.createImageView({
        height: 25,
        width: 25,
        id: "arrowImage"
    });
    $.__views.buttonView.add($.__views.arrowImage);
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.init = function(args) {
        $.arrowImage.image = WPATH(args.image);
        for (var prop in args.propertiesForButton) $.buttonView[prop] = args.propertiesForButton[prop];
    };
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;