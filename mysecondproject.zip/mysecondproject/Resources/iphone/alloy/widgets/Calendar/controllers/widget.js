function WPATH(s) {
    var index = s.lastIndexOf("/");
    var path = -1 === index ? "Calendar/" + s : s.substring(0, index) + "/Calendar/" + s.substring(index + 1);
    return path;
}

function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function _makeDaysView(args) {
        var lastSelectedDate = void 0;
        var previousMonthDatesEnd = args.numberOfDaysInAPreviousMonth - (args.day_of_week_for_first_date - 1);
        Ti.API.info(previousMonthDatesEnd);
        var firstDayOftheWeek = args.day_of_week_for_first_date;
        var nextMonthDatesStart = 1;
        for (var i = 0; 42 > i; i++) {
            if (i % 7 == 0) {
                dateContainer = Widget.createController("dateContainer").getView();
                0 == i && (dateContainer.top = "3%");
                $.datesView.add(dateContainer);
            }
            if (args.day_of_week_for_first_date >= 0) {
                if (i <= args.day_of_week_for_first_date - 1) var dateView = Widget.createController("dateView", {
                    date: previousMonthDatesEnd++,
                    backgroundColor: "#6E6E6E",
                    textColor: "#A4A4A4"
                }).getView(); else {
                    var dateView = Widget.createController("dateView", {
                        date: 1,
                        backgroundColor: "#FFFFFF",
                        textColor: "#2E2E2E"
                    }).getView();
                    dateView.addEventListener("click", function() {
                        if (void 0 == lastSelectedDate) {
                            this.backgroundColor = "#4B7FE1";
                            this.children[0].color = "#FFFFFF";
                            lastSelectedDate = this;
                        } else {
                            lastSelectedDate.backgroundColor = "#FFFFFF";
                            lastSelectedDate.children[0].color = "#2E2E2E";
                            this.backgroundColor = "#4B7FE1";
                            this.children[0].color = "#FFFFFF";
                            lastSelectedDate = this;
                        }
                        $.selectedDate = this.children[0].text;
                        $.topDateLabel.text = $.selectedDate + "/" + ($.selectedMonth + 1) + "/" + $.selectedYear;
                    });
                    args.day_of_week_for_first_date = -1;
                }
                0 == i && (dateView.left = "1%");
                dateContainer.add(dateView);
            } else {
                for (var j = 0; j < args.numberOfDaysInAMonth - 1; j++) {
                    if (6 - firstDayOftheWeek > j) {
                        var dateView = Widget.createController("dateView", {
                            date: j + 2,
                            backgroundColor: "#FFFFFF",
                            textColor: "#2E2E2E"
                        }).getView();
                        dateView.addEventListener("click", function() {
                            if (void 0 == lastSelectedDate) {
                                this.backgroundColor = "#4B7FE1";
                                this.children[0].color = "#FFFFFF";
                                lastSelectedDate = this;
                            } else {
                                lastSelectedDate.backgroundColor = "#FFFFFF";
                                lastSelectedDate.children[0].color = "#2E2E2E";
                                this.backgroundColor = "#4B7FE1";
                                this.children[0].color = "#FFFFFF";
                                lastSelectedDate = this;
                            }
                            $.selectedDate = this.children[0].text;
                            $.topDateLabel.text = $.selectedDate + "/" + ($.selectedMonth + 1) + "/" + $.selectedYear;
                        });
                        dateContainer.add(dateView);
                    } else {
                        if (7 == dateContainer.children.length) {
                            dateContainer = Widget.createController("dateContainer").getView();
                            $.datesView.add(dateContainer);
                        }
                        var dateView = Widget.createController("dateView", {
                            date: j + 2,
                            backgroundColor: "#FFFFFF",
                            textColor: "#2E2E2E"
                        }).getView();
                        dateView.addEventListener("click", function() {
                            if (void 0 == lastSelectedDate) {
                                this.backgroundColor = "#4B7FE1";
                                this.children[0].color = "#FFFFFF";
                                lastSelectedDate = this;
                            } else {
                                lastSelectedDate.backgroundColor = "#FFFFFF";
                                lastSelectedDate.children[0].color = "#2E2E2E";
                                this.backgroundColor = "#4B7FE1";
                                this.children[0].color = "#FFFFFF";
                                lastSelectedDate = this;
                            }
                            $.selectedDate = this.children[0].text;
                            $.topDateLabel.text = $.selectedDate + "/" + ($.selectedMonth + 1) + "/" + $.selectedYear;
                        });
                        0 == dateContainer.children.length && (dateView.left = "1%");
                        dateContainer.add(dateView);
                    }
                    i = args.numberOfDaysInAMonth;
                }
                for (var k = 0; k < 7 - args.day_of_week_for_last_date; k++) {
                    var dateView = Widget.createController("dateView", {
                        date: nextMonthDatesStart++,
                        backgroundColor: "#6E6E6E",
                        textColor: "#A4A4A4"
                    }).getView();
                    dateContainer.add(dateView);
                }
                args.day_of_week_for_last_date = 7;
                args.numberOfDaysInAMonth = 0;
            }
        }
    }
    var Widget = new (require("alloy/widget"))("Calendar");
    this.__widgetId = "Calendar";
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "widget";
    if (arguments[0]) {
        __processArg(arguments[0], "__parentSymbol");
        __processArg(arguments[0], "$model");
        __processArg(arguments[0], "__itemTemplate");
    }
    var $ = this;
    var exports = {};
    $.__views.calendarContainer = Ti.UI.createView({
        backgroundColor: "#FFFFFF",
        height: 320,
        width: 320,
        layout: "vertical",
        id: "calendarContainer"
    });
    $.__views.calendarContainer && $.addTopLevelView($.__views.calendarContainer);
    $.__views.topDate = Ti.UI.createView({
        top: 0,
        height: 40,
        width: Ti.UI.FILL,
        backgroundColor: "transparent",
        id: "topDate"
    });
    $.__views.calendarContainer.add($.__views.topDate);
    $.__views.topDateLabel = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#2ECCFA",
        font: {
            fontSize: 17
        },
        id: "topDateLabel"
    });
    $.__views.topDate.add($.__views.topDateLabel);
    $.__views.topSeparator = Ti.UI.createView({
        width: Ti.UI.FILL,
        height: 2,
        backgroundGradient: {
            type: "linear",
            startPoint: {
                x: "0%",
                y: "50%"
            },
            endPoint: {
                x: "100%",
                y: "50%"
            },
            colors: [ {
                color: "#086A87",
                offset: 0
            }, {
                color: "#045FB4",
                offset: .25
            }, {
                color: "#0080FF",
                offset: 1
            } ]
        },
        top: 0,
        id: "topSeparator"
    });
    $.__views.calendarContainer.add($.__views.topSeparator);
    $.__views.month_year_view = Ti.UI.createView({
        height: 40,
        width: Ti.UI.FILL,
        top: 0,
        backgroundColor: "transparent",
        layout: "horizontal",
        id: "month_year_view"
    });
    $.__views.calendarContainer.add($.__views.month_year_view);
    $.__views.monthView = Ti.UI.createView({
        height: 40,
        width: "49.5%",
        left: 0,
        id: "monthView"
    });
    $.__views.month_year_view.add($.__views.monthView);
    $.__views.previousMonth = Alloy.createWidget("Calendar", "Arrow", {
        id: "previousMonth",
        __parentSymbol: $.__views.monthView
    });
    $.__views.previousMonth.setParent($.__views.monthView);
    $.__views.monthNameLabel = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#424242",
        font: {
            fontSize: 12
        },
        left: 42,
        right: 42,
        textAlign: "center",
        id: "monthNameLabel"
    });
    $.__views.monthView.add($.__views.monthNameLabel);
    $.__views.nextMonth = Alloy.createWidget("Calendar", "Arrow", {
        id: "nextMonth",
        __parentSymbol: $.__views.monthView
    });
    $.__views.nextMonth.setParent($.__views.monthView);
    $.__views.verticalSeparator = Ti.UI.createView({
        height: 40,
        width: "0.5%",
        left: 0,
        backgroundGradient: {
            type: "linear",
            startPoint: {
                x: "0%",
                y: "50%"
            },
            endPoint: {
                x: "100%",
                y: "50%"
            },
            colors: [ {
                color: "#086A87",
                offset: 0
            }, {
                color: "#045FB4",
                offset: .25
            }, {
                color: "#0080FF",
                offset: 1
            } ]
        },
        id: "verticalSeparator"
    });
    $.__views.month_year_view.add($.__views.verticalSeparator);
    $.__views.yearView = Ti.UI.createView({
        height: 40,
        width: "49.5%",
        left: 0,
        id: "yearView"
    });
    $.__views.month_year_view.add($.__views.yearView);
    $.__views.previousYear = Alloy.createWidget("Calendar", "Arrow", {
        id: "previousYear",
        __parentSymbol: $.__views.yearView
    });
    $.__views.previousYear.setParent($.__views.yearView);
    $.__views.yearNameLabel = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#424242",
        font: {
            fontSize: 12
        },
        left: 42,
        right: 42,
        textAlign: "center",
        id: "yearNameLabel"
    });
    $.__views.yearView.add($.__views.yearNameLabel);
    $.__views.nextYear = Alloy.createWidget("Calendar", "Arrow", {
        id: "nextYear",
        __parentSymbol: $.__views.yearView
    });
    $.__views.nextYear.setParent($.__views.yearView);
    $.__views.daysView = Ti.UI.createView({
        height: 20,
        width: Ti.UI.FILL,
        top: 0,
        backgroundColor: "#FFFFFF",
        layout: "horizontal",
        id: "daysView"
    });
    $.__views.calendarContainer.add($.__views.daysView);
    $.__views.datesView = Ti.UI.createView({
        top: 0,
        bottom: 0,
        width: Ti.UI.FILL,
        backgroundColor: "transparent",
        layout: "vertical",
        id: "datesView"
    });
    $.__views.calendarContainer.add($.__views.datesView);
    exports.destroy = function() {};
    _.extend($, $.__views);
    Ti.include(WPATH("utils.js"));
    var dateContainer = void 0;
    var now = new Date();
    var currentMonth = now.getMonth();
    var currentDate = now.getDate();
    var currentYear = now.getFullYear();
    var numberOfDaysInAMonth = _getNumberOfDaysInMonth({
        year: currentYear,
        month: currentMonth
    });
    var day_of_week_for_first_date = _getWeekDay({
        year: currentYear,
        month: currentMonth,
        date: 1
    });
    var day_of_week_for_last_date = _getWeekDay({
        year: currentYear,
        month: currentMonth,
        date: numberOfDaysInAMonth
    });
    var numberOfDaysInAPreviousMonth = _getNumberOfDaysInMonth({
        year: currentYear,
        month: currentMonth - 1
    });
    _getNumberOfDaysInMonth({
        year: currentYear,
        month: currentMonth + 1
    });
    $.selectedDate = currentDate;
    $.selectedMonth = currentMonth;
    $.selectedYear = currentYear;
    var daysNameArr = [ "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" ];
    for (var i = 0, j = daysNameArr.length; j > i; i++) {
        var dayName = Widget.createController("daysView", {
            dayName: daysNameArr[i]
        }).getView();
        0 == i && (dayName.left = "1%");
        $.daysView.add(dayName);
    }
    $.previousMonth.init({
        image: "previous.png",
        propertiesForButton: {
            left: 0
        }
    });
    $.previousMonth.__views.buttonView.addEventListener("click", function() {
        if (0 == currentMonth) ; else {
            var month = --currentMonth;
            $.selectedMonth = month;
            _getMonthName(month, $.monthNameLabel);
            $.topDateLabel.text = $.selectedDate + "/" + ($.selectedMonth + 1) + "/" + $.selectedYear;
            day_of_week_for_first_date = _getWeekDay({
                year: currentYear,
                month: month,
                date: 1
            });
            numberOfDaysInAMonth = _getNumberOfDaysInMonth({
                year: currentYear,
                month: month
            });
            day_of_week_for_last_date = _getWeekDay({
                year: currentYear,
                month: month,
                date: numberOfDaysInAMonth
            });
            numberOfDaysInAPreviousMonth = _getNumberOfDaysInMonth({
                year: currentYear,
                month: month - 1
            });
            $.datesView.removeAllChildren();
            _makeDaysView({
                day_of_week_for_first_date: day_of_week_for_first_date,
                numberOfDaysInAMonth: numberOfDaysInAMonth,
                numberOfDaysInAPreviousMonth: numberOfDaysInAPreviousMonth,
                day_of_week_for_last_date: day_of_week_for_last_date
            });
        }
    });
    $.nextMonth.init({
        image: "next.png",
        propertiesForButton: {
            right: 0
        }
    });
    $.nextMonth.__views.buttonView.addEventListener("click", function() {
        if (11 == currentMonth) ; else {
            var month = ++currentMonth;
            $.selectedMonth = month;
            _getMonthName(month, $.monthNameLabel);
            $.topDateLabel.text = $.selectedDate + "/" + (month + 1) + "/" + $.selectedYear;
            day_of_week_for_first_date = _getWeekDay({
                year: currentYear,
                month: month,
                date: 1
            });
            numberOfDaysInAMonth = _getNumberOfDaysInMonth({
                year: currentYear,
                month: month
            });
            day_of_week_for_last_date = _getWeekDay({
                year: currentYear,
                month: month,
                date: numberOfDaysInAMonth
            });
            numberOfDaysInAPreviousMonth = _getNumberOfDaysInMonth({
                year: currentYear,
                month: month - 1
            });
            $.datesView.removeAllChildren();
            _makeDaysView({
                day_of_week_for_first_date: day_of_week_for_first_date,
                numberOfDaysInAMonth: numberOfDaysInAMonth,
                numberOfDaysInAPreviousMonth: numberOfDaysInAPreviousMonth,
                day_of_week_for_last_date: day_of_week_for_last_date
            });
        }
    });
    $.previousYear.init({
        image: "previous.png",
        propertiesForButton: {
            left: 0
        }
    });
    $.previousYear.__views.buttonView.addEventListener("click", function() {
        var year = --currentYear;
        $.selectedYear = year;
        $.yearNameLabel.text = year;
        $.topDateLabel.text = $.selectedDate + "/" + ($.selectedMonth + 1) + "/" + $.selectedYear;
        day_of_week_for_first_date = _getWeekDay({
            year: year,
            month: currentMonth,
            date: 1
        });
        numberOfDaysInAMonth = _getNumberOfDaysInMonth({
            year: year,
            month: currentMonth
        });
        day_of_week_for_last_date = _getWeekDay({
            year: year,
            month: currentMonth,
            date: numberOfDaysInAMonth
        });
        numberOfDaysInAPreviousMonth = _getNumberOfDaysInMonth({
            year: year,
            month: currentMonth - 1
        });
        $.datesView.removeAllChildren();
        _makeDaysView({
            day_of_week_for_first_date: day_of_week_for_first_date,
            numberOfDaysInAMonth: numberOfDaysInAMonth,
            numberOfDaysInAPreviousMonth: numberOfDaysInAPreviousMonth,
            day_of_week_for_last_date: day_of_week_for_last_date
        });
    });
    $.nextYear.init({
        image: "next.png",
        propertiesForButton: {
            right: 0
        }
    });
    $.nextYear.__views.buttonView.addEventListener("click", function() {
        var year = ++currentYear;
        $.selectedYear = year;
        $.yearNameLabel.text = year;
        $.topDateLabel.text = $.selectedDate + "/" + ($.selectedMonth + 1) + "/" + $.selectedYear;
        day_of_week_for_first_date = _getWeekDay({
            year: year,
            month: currentMonth,
            date: 1
        });
        numberOfDaysInAMonth = _getNumberOfDaysInMonth({
            year: year,
            month: currentMonth
        });
        day_of_week_for_last_date = _getWeekDay({
            year: year,
            month: currentMonth,
            date: numberOfDaysInAMonth
        });
        numberOfDaysInAPreviousMonth = _getNumberOfDaysInMonth({
            year: year,
            month: currentMonth - 1
        });
        $.datesView.removeAllChildren();
        _makeDaysView({
            day_of_week_for_first_date: day_of_week_for_first_date,
            numberOfDaysInAMonth: numberOfDaysInAMonth,
            numberOfDaysInAPreviousMonth: numberOfDaysInAPreviousMonth,
            day_of_week_for_last_date: day_of_week_for_last_date
        });
    });
    $.topDateLabel.text = now.getDate() + "/" + (now.getMonth() + 1) + "/" + now.getFullYear();
    _getMonthName(new Date().getMonth(), $.monthNameLabel);
    $.yearNameLabel.text = new Date().getFullYear();
    _makeDaysView({
        day_of_week_for_first_date: day_of_week_for_first_date,
        numberOfDaysInAMonth: numberOfDaysInAMonth,
        numberOfDaysInAPreviousMonth: numberOfDaysInAPreviousMonth,
        day_of_week_for_last_date: day_of_week_for_last_date
    });
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;