function WPATH(s) {
    var index = s.lastIndexOf("/");
    var path = -1 === index ? "Calendar/" + s : s.substring(0, index) + "/Calendar/" + s.substring(index + 1);
    return path;
}

function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    new (require("alloy/widget"))("Calendar");
    this.__widgetId = "Calendar";
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "dateView";
    if (arguments[0]) {
        __processArg(arguments[0], "__parentSymbol");
        __processArg(arguments[0], "$model");
        __processArg(arguments[0], "__itemTemplate");
    }
    var $ = this;
    var exports = {};
    $.__views.dateView = Ti.UI.createView({
        height: Ti.UI.FILL,
        width: "14%",
        backgroundColor: "#FFFFFF",
        borderColor: "#A3A4AE",
        id: "dateView"
    });
    $.__views.dateView && $.addTopLevelView($.__views.dateView);
    $.__views.dateLabel = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#424242",
        font: {
            fontSize: 13
        },
        textAlign: "center",
        id: "dateLabel"
    });
    $.__views.dateView.add($.__views.dateLabel);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var args = arguments[0] || {};
    $.dateLabel.text = args.date;
    $.dateLabel.color = args.textColor;
    $.dateView.backgroundColor = args.backgroundColor;
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;