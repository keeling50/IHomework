function WPATH(s) {
    var index = s.lastIndexOf("/");
    var path = -1 === index ? "Calendar/" + s : s.substring(0, index) + "/Calendar/" + s.substring(index + 1);
    return path;
}

module.exports = [ {
    isApi: true,
    priority: 1000.0002,
    key: "Label",
    style: {
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000"
    }
}, {
    isApi: true,
    priority: 1000.0003,
    key: "Button",
    style: {
        borderColor: "grey",
        borderWidth: ".5em",
        width: "60%",
        color: "black"
    }
}, {
    isApi: true,
    priority: 1000.0007,
    key: "TextField",
    style: {
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
        borderColor: "black"
    }
}, {
    isApi: true,
    priority: 1101.0004,
    key: "Label",
    style: {
        color: "blue"
    }
}, {
    isClass: true,
    priority: 10000.0001,
    key: "container",
    style: {
        backgroundColor: "white",
        exitOnClose: true
    }
}, {
    isId: true,
    priority: 100000.0005,
    key: "dateView",
    style: {
        height: Ti.UI.FILL,
        width: "14%",
        backgroundColor: "#FFFFFF",
        borderColor: "#A3A4AE"
    }
}, {
    isId: true,
    priority: 100000.0006,
    key: "dateLabel",
    style: {
        color: "#424242",
        font: {
            fontSize: 13
        },
        textAlign: "center"
    }
} ];