function WPATH(s) {
    var index = s.lastIndexOf("/");
    var path = -1 === index ? "Calendar/" + s : s.substring(0, index) + "/Calendar/" + s.substring(index + 1);
    return path;
}

module.exports = [ {
    isApi: true,
    priority: 1000.0002,
    key: "Label",
    style: {
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000"
    }
}, {
    isApi: true,
    priority: 1000.0003,
    key: "Button",
    style: {
        borderColor: "grey",
        borderWidth: ".5em",
        width: "60%",
        color: "black"
    }
}, {
    isApi: true,
    priority: 1000.0007,
    key: "TextField",
    style: {
        borderStyle: Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
        borderColor: "black"
    }
}, {
    isApi: true,
    priority: 1101.0004,
    key: "Label",
    style: {
        color: "blue"
    }
}, {
    isClass: true,
    priority: 10000.0001,
    key: "container",
    style: {
        backgroundColor: "white",
        exitOnClose: true
    }
}, {
    isClass: true,
    priority: 10000.0014,
    key: "mothDateView",
    style: {
        height: 40,
        width: "49.5%",
        left: 0
    }
}, {
    isClass: true,
    priority: 10000.0016,
    key: "month_year_label",
    style: {
        font: {
            fontSize: 12
        },
        height: Ti.UI.SIZE,
        left: 42,
        right: 42,
        color: "#424242",
        textAlign: "center"
    }
}, {
    isId: true,
    priority: 100000.0009,
    key: "calendarContainer",
    style: {
        backgroundColor: "#FFFFFF",
        height: 320,
        width: 320,
        layout: "vertical"
    }
}, {
    isId: true,
    priority: 100000.001,
    key: "topDate",
    style: {
        top: 0,
        height: 40,
        width: Ti.UI.FILL,
        backgroundColor: "transparent"
    }
}, {
    isId: true,
    priority: 100000.0011,
    key: "topDateLabel",
    style: {
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        font: {
            fontSize: 17
        },
        color: "#2ECCFA"
    }
}, {
    isId: true,
    priority: 100000.0012,
    key: "topSeparator",
    style: {
        width: Ti.UI.FILL,
        height: 2,
        backgroundGradient: {
            type: "linear",
            startPoint: {
                x: "0%",
                y: "50%"
            },
            endPoint: {
                x: "100%",
                y: "50%"
            },
            colors: [ {
                color: "#086A87",
                offset: 0
            }, {
                color: "#045FB4",
                offset: .25
            }, {
                color: "#0080FF",
                offset: 1
            } ]
        },
        top: 0
    }
}, {
    isId: true,
    priority: 100000.0013,
    key: "month_year_view",
    style: {
        height: 40,
        width: Ti.UI.FILL,
        top: 0,
        backgroundColor: "transparent",
        layout: "horizontal"
    }
}, {
    isId: true,
    priority: 100000.0015,
    key: "verticalSeparator",
    style: {
        height: 40,
        width: "0.5%",
        left: 0,
        backgroundGradient: {
            type: "linear",
            startPoint: {
                x: "0%",
                y: "50%"
            },
            endPoint: {
                x: "100%",
                y: "50%"
            },
            colors: [ {
                color: "#086A87",
                offset: 0
            }, {
                color: "#045FB4",
                offset: .25
            }, {
                color: "#0080FF",
                offset: 1
            } ]
        }
    }
}, {
    isId: true,
    priority: 100000.0017,
    key: "daysView",
    style: {
        height: 20,
        width: Ti.UI.FILL,
        top: 0,
        backgroundColor: "#FFFFFF",
        layout: "horizontal"
    }
}, {
    isId: true,
    priority: 100000.0018,
    key: "datesView",
    style: {
        top: 0,
        bottom: 0,
        width: Ti.UI.FILL,
        backgroundColor: "transparent",
        layout: "vertical"
    }
} ];