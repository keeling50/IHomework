function _getMonthName(monthNumber, labelObj) {
    switch (monthNumber) {
      case 0:
        labelObj.text = "January";
        break;

      case 1:
        labelObj.text = "February";
        break;

      case 2:
        labelObj.text = "March";
        break;

      case 3:
        labelObj.text = "April";
        break;

      case 4:
        labelObj.text = "May";
        break;

      case 5:
        labelObj.text = "June";
        break;

      case 6:
        labelObj.text = "July";
        break;

      case 7:
        labelObj.text = "August";
        break;

      case 8:
        labelObj.text = "September";
        break;

      case 9:
        labelObj.text = "October";
        break;

      case 10:
        labelObj.text = "November";
        break;

      case 11:
        labelObj.text = "December";
    }
}

var _getNumberOfDaysInMonth = function(args) {
    var monthStart = new Date(args.year, args.month, 1);
    var monthEnd = new Date(args.year, args.month + 1, 1);
    var monthLength = (monthEnd - monthStart) / 864e5;
    return monthLength;
};

var _getWeekDay = function(args) {
    return new Date(parseInt(args.year), parseInt(args.month), parseInt(args.date)).getDay();
};